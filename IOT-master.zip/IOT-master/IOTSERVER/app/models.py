from app import db
from flask import current_app
from app import create_app
from . import login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from flask_login import UserMixin,current_user
from app.email import send_async_email
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
class Permission():
    #设备
    ADD_DEVICE = 0X0001
    DELETE_DEVICE = 0X0002
    EDIT_DEVICE = 0X0004

    #传感器
    ADD_SENSOR = 0X0008
    DELETE_SENSOR = 0X0010
    EDIT_SENSOR = 0X0020

    #用户
    ADD_USER = 0X0040
    DELETE_USER = 0X0080
    EDIT_USER = 0X0100


class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(128))
    name = db.Column(db.String(128), default='张三')
    password_hash = db.Column(db.String(128))
    #api接口
    API_KEY = db.Column(db.String(128))

    # 外键  角色
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))

    about_me = db.Column(db.Text)
    location = db.Column(db.String(64))
    #注册时间和最后访问时间
    register_time = db.Column(db.DateTime, default=datetime.now)
    access_time = db.Column(db.DateTime, default=datetime.now)
    confirmed = db.Column(db.Boolean, default=False)


    #生成API_KEY
    def genrate_api_token(self):
        s = Serializer(secret_key=current_app.config['SECRET_KEY'], expires_in=60*60*24*90068)
        self.API_KEY = s.dumps({'id': self.id})
        db.session.add(self)
        db.session.commit()


    def get_api_token(self):
        return self.API_KEY

    @staticmethod
    def check_api_key(token):
        s = Serializer(secret_key=current_app.config['SECRET_KEY'])
        try:
            data = s.loads(token)
        except:
            return None
        if 'id' not in data.keys():
            return None
        return User.query.filter_by(id=int(data['id'])).first()





 #-------为了做用户邮箱激活-----------------------------------#

    def generate_confirmed_token(self):
        s = Serializer(secret_key=current_app.config['SECRET_KEY'], expires_in=120)
        token = s.dumps({'id': self.id})
        return token

    def confirm(self, token):
        s = Serializer(secret_key=current_app.config['SECRET_KEY'])
        try :
            #token如果超时的话会由异常
            d = s.loads(token)
        except :
            return False

        if d.get('id') == self.id :
            self.confirmed = True
            db.session.add(self)
            db.session.commit()
            return True
        return False

    #-------为了做用户邮箱激活-----------------------------------#
    def __str__(self):
        return str(self.id)+":"+self.name

    #构建一个属性
    @property
    def password(self):
        #密码不能读取，如果读取抛出异常
        raise AttributeError('密码不能读取')
    @password.setter
    def password(self, password):
        #利用sha256+杂质串的方式产生hash值
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        #验证密码是否正确
        return check_password_hash(self.password_hash, password)


    #----------------实现权限认证的方法--------------------#
    def has_permission(self, permission):
        return self.role.permissions & permission == permission
    def is_admin(self):
        return self.has_permission(0XFFFF)

    def flush_access_time(self):
        self.access_time = datetime.now()
        db.session.add(self)
        db.session.commit()


    @login_manager.user_loader
    def load_user(id):
        return User.query.get(int(id))


    #反向关系
    logs = db.relationship('Log', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    devices = db.relationship('Device', backref='user', lazy='dynamic', cascade='all, delete-orphan')

from flask_login import AnonymousUserMixin
class AnonymousUser(AnonymousUserMixin):
    name = '游客'

    def has_permission(self, permission):
        return False

    def is_admin(self):
        return False

    def flush_access_time(self):
        pass




class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64))
    permissions = db.Column(db.Integer)
    default = db.Column(db.Boolean, default=False)

    users = db.relationship('User', backref='role')

    @staticmethod
    def create_roles():
        roles = {
            'user': [Permission.ADD_DEVICE | Permission.ADD_SENSOR | Permission.DELETE_DEVICE | Permission.DELETE_SENSOR | Permission.EDIT_DEVICE | Permission.EDIT_SENSOR | Permission.EDIT_USER, True],
            'Enterprise_users': [Permission.EDIT_SENSOR | Permission.EDIT_DEVICE | Permission.EDIT_USER, False],
            'admin': [0XFFFF, False],
        }
        for r in roles:
            role = Role.query.filter_by(name=r).first()
            if role is None:
                role = Role()
                role.name = r
            role.permissions = roles[r][0]
            role.default = roles[r][1]
            db.session.add(role)
        db.session.commit()


class Device(db.Model):
    __tablename__ = 'devices'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    about_device = db.Column(db.Text)
    local = db.Column(db.String(64))
    set_time = db.Column(db.DateTime, default=datetime.now)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    sensors = db.relationship('Sensor', backref='device',
                              lazy='dynamic',
                              cascade='all, delete-orphan')
    def to_json(self):
        json_data = {
            'id': self.id,
            'name': self.name,
            'about_device': self.about_device,
            'local': self.local,
            'set_time': self.set_time,
            'user': self.user.name
        }
        return json_data
class Sensor(db.Model):
    __tablename__ = 'sensors'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    about_sensor = db.Column(db.Text)
    #单位
    unit = db.Column(db.String(32))
    max = db.Column(db.FLOAT)
    min = db.Column(db.FLOAT)
    set_time = db.Column(db.DateTime, default=datetime.now)
    device_id = db.Column(db.Integer, db.ForeignKey('devices.id'))

    datas = db.relationship('Data',
                            backref='sensor',
                            lazy='dynamic',
                            cascade='all, delete-orphan')
    def to_json(self):
        json_data = {
            'id': self.id,
            'name': self.name,
            'about_sensor': self.about_sensor,
            'unit': self.unit,
            'max': self.max,
            'min': self.min,
            'set_time': self.set_time,
            'device': self.device.name
        }
        return json_data


class Data(db.Model):
    __tablename__='datas'
    id = db.Column(db.Integer, primary_key=True)
    about_data = db.Column(db.Text)
    set_time = db.Column(db.DateTime, default=datetime.utcnow)
    sensor_id = db.Column(db.Integer, db.ForeignKey('sensors.id'))
    alerts = db.relationship('Alert', backref='data', lazy='dynamic', cascade='all, delete-orphan')

    def to_json(self):
        json_data={
            'id': self.id,
            'about_data': self.about_data,
            'set_time': self.set_time,
            'sensor': self.sensor.name
        }
        return json_data

class Alert(db.Model):
    __tablename__ = 'alerts'
    id = db.Column(db.Integer, primary_key=True)
    warning_data_id = db.Column(db.Integer, db.ForeignKey('datas.id'))
    warning_data_max = db.Column(db.FLOAT)
    warning_data_min = db.Column(db.FLOAT)
    warning_time = db.Column(db.DateTime, default=datetime.now)
    warning_reason = db.Column(db.Text)

class Log(db.Model):
    __tablename__ = 'logs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    title = db.Column(db.Text)
    body= db.Column(db.Text)

    post_time = db.Column(db.DateTime, default=datetime.now)






