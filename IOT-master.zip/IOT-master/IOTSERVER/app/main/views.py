from flask import render_template,redirect,url_for
from app import create_app
from app import db
from . import main
from ..auth.forms import LoginForm
from app.models import User
from flask import abort,flash,request
from flask_login import login_user, logout_user, login_required, current_user

from app.models import Log
@main.route('/', methods=['GET', 'POST'])
def index():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        user = User.query.filter_by(email=email).first()
        if user is None:
            abort(404)
        if user.check_password(password):
            login_user(user, True)
            return redirect(url_for('main.user_info', id=user.id))
        else:
            flash('邮箱或者密码错误')
            return redirect(url_for('main.index'))

    return render_template('main/index.html', form=form)

@main.route('/user_info', methods=['GET', 'POST'])
def user_info():
    id = request.args.get('id')
    if id is None:
        abort(404)
    user = User.query.filter_by(id=id).first()
    logs = user.logs.all()
    if user is None:
        abort(404)

    return render_template('main/user.html', user=user, logs=logs)

@main.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))

from .forms import EditUser_admin
@main.route('/edit_admin', methods=['GET', 'POST'])
def edit_admin():
    id = request.args.get('id')
    if id is None:
        abort(404)
    user = User.query.filter_by(id=id).first()
    if user is None:
        abort(404)
    form = EditUser_admin()
    if form.validate_on_submit():
        user.name = form.name.data
        user.email = user.email
        user.confirmed = form.confirmed.data
        user.role_id = form.role_id.data
        user.about_me = form.about_me.data
        user.location = form.location.data
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('main.user_info', id=user.id))
    form.email.data=user.email
    form.name.data=user.name
    form.role_id.data=user.role_id
    form.about_me.data=user.about_me
    form.location.data=user.location
    form.confirmed.data=user.confirmed
    return render_template('main/edit_admin.html', form=form)

from .forms import EditUser
@main.route('/edit_user', methods=['GET', 'POST'])
@login_required
def edit_user():
    form = EditUser()
    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.about_me = form.about_me.data
        current_user.location = form.location.data
        if len(form.password.data) != 0 :
            current_user.password = form.password.data
        db.session.add(current_user)
        db.session.commit()
        return redirect(url_for('main.user_info', id=current_user.id,))

    form.email.data = current_user.email
    form.name.data = current_user.name
    # form.password.data = '*******'
    # form.password_again.data = '*******'
    form.location.data = current_user.location
    form.about_me.data = current_user.about_me
    return render_template('main/edit_user.html', form=form)
from .forms import LogForm
from app.models import Log
@main.route('/post_log', methods=['GET','POST'])
@login_required
def post_log():
    form = LogForm()
    if form.validate_on_submit():
        logs = Log()
        logs.body = form.body.data
        logs.title = form.title.data
        logs.user_id = current_user.id
        db.session.add(logs)
        db.session.commit()
        return redirect(url_for('main.user_info', id=current_user.id))
    return render_template('main/post_log.html', form=form)

@main.route('/delete_log', methods=['GET', 'POST'])
@login_required
def delete_log():
    lid = request.args.get('lid')

    log = Log.query.filter_by(id=lid).first()

    if log.user_id == current_user.id:
        db.session.delete(log)
        db.session.commit()
        return redirect(url_for('main.user_info', id=log.user_id))
    return redirect(url_for('main.user_info', id=log.user_id))

from app.models import Device
@main.route('/my_devices', methods=['GET', 'POST'])
@login_required
def my_devices():
    id = request.args.get('id')

    if id is None:
        abort(404)
    user = User.query.filter_by(id=id).first()
    if user is None:
        abort(404)
    page_index = request.args.get('page', default=1, type=int)
    query = user.devices
    paginate = query.order_by(Device.set_time.desc()).paginate(page_index, 20,
                                                                       False)
    return render_template('main/shebei.html', id=id, paginate=paginate)


@main.route('/device', methods=['GET', 'POST'])
@login_required
def device():
    did = request.args.get('did')
    if did is None:
        abort(404)
    device = Device.query.filter_by(id=did).first()
    if device is None:
        abort(404)
    sensor = device.sensors.all()
    return render_template('main/sbxq.html', did=did, device=device, sensor=sensor)
from .forms import DeviceForm
@main.route('/add_device', methods=['GET', 'POST'])
@login_required
def add_device():
    form = DeviceForm()
    device = Device()
    if form.validate_on_submit():
        device.name = form.name.data
        device.about_device = form.about_device.data
        device.local = form.local.data
        device.user_id = current_user.id
        db.session.add(device)
        db.session.commit()
        return redirect(url_for('main.my_devices', id=current_user.id))

    return render_template('main/add_device.html',form=form)


@main.route('/delete_device', methods=['GET', 'POST'])
@login_required
def delete_device():
    did=request.args.get('did')
    if did is None:
        abort(404)
    device = Device.query.filter_by(id=did).first()
    if device is None:
        abort(404)
    db.session.delete(device)
    db.session.commit()
    return redirect(url_for('main.my_devices', id=current_user.id))

from .forms import EditDeviceForm

@main.route('/edit_device', methods=['GET', 'POST'])
@login_required
def edit_device():
    did=request.args.get('did')
    form = EditDeviceForm()
    device = Device.query.filter_by(id=did).first()
    if form.validate_on_submit():
        device.name = form.name.data
        device.about_device = form.about_device.data
        device.local = form.local.data
        device.user_id = current_user.id
        db.session.add(device)
        db.session.commit()
        return redirect(url_for('main.my_devices', id=current_user.id))

    return render_template('main/edit_device.html', form=form)

from .forms import SensorsForm
from app.models import Sensor
@main.route('/add_sensor', methods=['GET', 'POST'])
@login_required
def add_sensor():
    did = request.args.get('did')
    form = SensorsForm()
    sensor = Sensor()
    if form.validate_on_submit():
        sensor.name = form.name.data
        sensor.about_sensor = form.about_sensor.data
        sensor.device_id = did
        sensor.max = form.max.data
        sensor.min = form.min.data
        sensor.unit = form.unit.data
        db.session.add(sensor)
        db.session.commit()
        return redirect(url_for('main.device', did=did))
    return render_template('main/add_sensor.html', form=form)

@main.route('/edit_sensor', methods=['GET', 'POST'])
@login_required
def edit_sensor():
    sid = request.args.get('sid')
    form = SensorsForm()
    sensor = Sensor.query.filter_by(id=sid).first()
    if sensor is None:
        abort(404)
    if form.validate_on_submit():
        sensor.name = form.name.data
        sensor.about_sensor = form.about_sensor.data
        sensor.device_id = sensor.device.id
        sensor.max = form.max.data
        sensor.min = form.min.data
        sensor.unit = form.unit.data
        db.session.add(sensor)
        db.session.commit()
        return redirect(url_for('main.device', did=sensor.device_id))
    form.name.data = sensor.name
    form.about_sensor.data = sensor.about_sensor
    form.unit.data = sensor.unit
    form.min.data = sensor.min
    form.max.data = sensor.max
    return render_template('main/edit_sensor.html', form=form)

@main.route('/delete_sensor', methods=['GET', 'POST'])
@login_required
def delete_sensor():
    sid = request.args.get('sid')
    if sid is None:
        abort(404)
    sensor = Sensor.query.filter_by(id=sid).first()
    if sensor is None:
        abort(404)
    db.session.delete(sensor)
    db.session.commit()
    return redirect(url_for('main.device', did=sensor.device_id))
from flask import jsonify
@main.route('/sensor_data', methods=['GET', 'POST'])
@login_required
def sensor_data():
    sid = request.args.get('sid')
    sensor = Sensor.query.filter_by(id=sid).first()
    if sensor is None:
        abort(404)
    datas = sensor.datas.all()
    count = int(len(datas)/2)
    xlist = []
    ylist = []
    datas1 = datas[:count:-1]
    datas2 = datas[count::-1]
    for d in datas:
        xlist.append(d.set_time.strftime("%H:%M:%S"))
        ylist.append(d.about_data)
    return render_template('main/cgq.html', sid=sid, xlist=xlist[-7:], ylist=ylist[-7:], datas1=datas1, datas2=datas2)






