from flask_wtf import FlaskForm
from wtforms import IntegerField, TextAreaField, BooleanField, PasswordField,StringField,SubmitField
from wtforms.validators import DataRequired, Email,Length,Regexp,EqualTo
from wtforms import SelectField, ValidationError
from app.models import User, Role
from wtforms.validators import ValidationError

class EditUser(FlaskForm):
    email = StringField(label='邮箱', validators=[DataRequired(), Email(), Length(1, 128)])
    name = StringField(label='昵称', validators=[DataRequired(), Length(1, 128)])
    about_me = TextAreaField(label='个人介绍', validators=[DataRequired(), Length(1, 128)])
    location = StringField(label='位置',validators=[DataRequired(), Length(1, 64)])
    password = PasswordField(label='密码')
    password_again = PasswordField(label='确认密码', validators=[EqualTo('password', '两次密码不一致')])
    submit = SubmitField(label='确认编辑')

class EditUser_admin(FlaskForm):
    email = StringField(label='邮箱', validators=[DataRequired(), Email(), Length(1, 128)])
    name = StringField(label='昵称', validators=[DataRequired(), Length(1, 128)])
    about_me = TextAreaField(label='个人介绍', validators=[DataRequired(), Length(1, 128)])
    location = StringField(label='位置',validators=[DataRequired(), Length(1, 64)])
    confirmed = BooleanField('验证')
    role_id = SelectField('Role', coerce=int)
    submit = SubmitField(label='确认编辑')
    def __init__(self, *args, **kwargs):
        super(EditUser_admin, self).__init__(*args, **kwargs)
        self.role_id.choices = [(role.id, role.name) for role in Role.query.order_by(Role.id).all()]

class LogForm(FlaskForm):
    title = TextAreaField(label='标题', validators=[DataRequired()])
    body = TextAreaField(label='内容', validators=[DataRequired()])
    submit = SubmitField('提交')

class DeviceForm(FlaskForm):
    name = StringField('设备名称', validators=[DataRequired(), Length(1, 64)])
    local = StringField('位置', validators=[DataRequired()])
    about_device = TextAreaField('设备描述')
    submit = SubmitField('提交')

class EditDeviceForm(FlaskForm):
    name = StringField('设备名称', validators=[DataRequired(), Length(1, 64)])
    local = StringField('位置', validators=[DataRequired()])
    about_device = TextAreaField('设备描述')
    submit = SubmitField('提交')

from wtforms import FloatField
class SensorsForm(FlaskForm):
    name = StringField('传感器名称', validators=[DataRequired(), Length(1, 64)])
    about_sensor = TextAreaField('传感器描述')
    unit = StringField('单位', validators=[DataRequired()])
    max = FloatField('上限', validators=[DataRequired()])
    min = FloatField('下限', validators=[DataRequired()])
    submit = SubmitField('提交')
