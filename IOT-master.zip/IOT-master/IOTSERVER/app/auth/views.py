from . import auth
from flask import render_template, url_for, redirect, abort
from flask_login import logout_user,login_user,login_required
from app.models import User
from flask import flash,request
from app import db
from flask_login import current_user
from flask import current_app
from app.models import Role
from app.email import send_async_email
from .forms import RegisterForm,LoginForm
@auth.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit() :
        #在这里可以放心使用表单 邮箱一定是唯一的
        user = User()
        user.email = form.email.data
        user.name = form.name.data
        user.password = form.password.data

        #'user','moderotor','admin'
        #如果用户注册的邮箱和config.py中发送邮件的邮箱一样，那么这个用户分配管理员
        if user.email == current_app.config['MAIL_USERNAME'] :
            user.role = Role.query.filter_by(name='admin').first()
        else :
            user.role = Role.query.filter_by(default=True).first()
        #其他用户都设置为user角色

        db.session.add(user)
        db.session.commit()
        user.genrate_api_token()

        token = user.generate_confirmed_token()
        print(1)
        html = render_template('email/register.html', token=token, user_name=user.name)
        print(2)
        send_async_email(subject='物联网云平台验证邮件', recvs=[user.email], body=None, html=html)
        print(3)
        flash('恭喜！注册成功！赶紧登陆！')
        return redirect(url_for('main.index'))

    return render_template('auth/register.html', form=form)

@auth.route('/resend_email')
@login_required
def resend_email():
    user = User.query.filter_by(id=current_user.id).first()
    token = user.generate_confirmed_token()
    html = render_template('email/register.html', token=token, user_name=user.name)
    send_async_email(subject='物联网云平台验证邮件', recvs=[user.email], body=None, html=html)

    return redirect(url_for('main.user_info', id=current_user.id))



@auth.route('/confirm')
@login_required
def confirm():
    token = request.args.get('token')
    if token is None:
        abort(404)
    if current_user.confirm(token):
        return redirect(url_for('main.user_info', id=current_user.id))
    return render_template('auth/resend_email.html')

# 钩子函数
# 这个函数会截获所有的请求
# 也就是用浏览器访问我们的路由的时候要先执行这个函数
@auth.before_app_request
def before_app_request() :
     #什么样的用户我们才截获？
     #1.已经登陆 and 没有认证 and 访问的不是auth.和stastic
     #print(request.endpoint)
    if current_user.is_authenticated:
        current_user.flush_access_time()
        if current_user.is_authenticated and\
            current_user.confirmed==False and \
            request.endpoint[:5] != 'auth.' and \
            request.endpoint != 'static':
            #注意：访问其他蓝本的时候，比如main蓝本时候，当前蓝本就是main
            return redirect(url_for('auth.unconfirmed'))

@auth.route('/unconfirmed')
@login_required
def unconfirmed():
    if not current_user.confirmed:
        return render_template('auth/unconfirmed.html', user=current_user)
    return redirect(url_for('main.user_info', id=current_user.id))


