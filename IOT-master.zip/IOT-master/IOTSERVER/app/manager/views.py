from . import manager
from flask_login import current_user , login_required
from flask import request, redirect, render_template, url_for, abort
from app.models import User
from app import db
@manager.route('/all_user')
def all_user():
    page_index = request.args.get('page', default=1, type=int)
    paginate = User.query.order_by(User.register_time.desc()).paginate(page_index, 20,
                                                                     False)

    return render_template('manager/glzx.html', paginate=paginate)
from app.models import Device
@manager.route('/all_device')
def all_device():
    page_index = request.args.get('page', default=1, type=int)
    paginate = Device.query.order_by(Device.set_time.desc()).paginate(page_index, 20,
                                                                     False)

    return render_template('manager/manager_device.html', paginate=paginate)



@manager.route('/delete_user', methods=['GET', 'POST'])
def delete_user():
    id = request.args.get('id')
    if id is None:
        abort(404)
    user = User.query.filter_by(id=id).first()
    if user is None:
        abort(404)
    if user.id != current_user.id and user.role != 'admin':
        db.session.delete(user)
        db.session.commit()
        return redirect(url_for('manager.all_user'))
    return redirect(url_for('manager.all_user'))
