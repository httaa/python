from flask_httpauth import HTTPBasicAuth
from flask import jsonify
from . import api
from app.models import User
from flask import request
#全局变量（对象）
from flask import g
from app.models import Device, Sensor, Data, Alert
from app import db

auth = HTTPBasicAuth()


#验证
@auth.verify_password
def verify_password(email_token, password):
    if len(email_token) == 0:
        return False

    if len(password) == 0:
        user = User.check_api_key(email_token)
        if user is None:
            return False
        g.current_user = user
        return True
    user = User.query.filter_by(email=email_token).first()
    if user is None:
        return False
    if user.check_password(password):
        g.current_user = user
        return True


    return False

@auth.error_handler
def error():
    return jsonify({'status': 403, 'info': 'auth error'})

@api.route('/')
@auth.login_required
def test():
    return jsonify({'status': 200, 'info':'welcom'})

#获取API_KEY
@api.route('/token')
@auth.login_required
def token():
    return jsonify({'status':200, 'token':g.current_user.API_KEY})

#获取自己所有设备
@api.route('/devices')
@auth.login_required
def devices():
    devices = g.current_user.devices.all()
    dlist = []
    for d in devices:
        dlist.append(d.to_json())
    return jsonify({'status':200, 'devices': dlist})


from app.models import Alert
#上传数据
@api.route('/device/<int:did>/sensor/<int:sid>/data', methods=['POST'])
@auth.login_required
def data(did, sid) :
    #print(type(request.json), request.json)
    device = g.current_user.devices.filter_by(id=did).first()
    if device is None :
        return jsonify({'status':404, 'info':'找不到你的设备'})

    sensor = device.sensors.filter_by(id=sid).first()
    if sensor is None :
        return jsonify({'status':404, 'info':'找不到你的传感器'})

    if request.json is None:
        return jsonify({'status': 404, 'info': '找不到你的数据'})

    if 'data' not in request.json.keys():
        return jsonify({'status': 404, 'info': '找不到你的数据'})


    data = Data()
    data.about_data = request.json.get('data')
    data.sensor_id = sid
    db.session.add(data)
    db.session.commit()
    # 在这里判断要不要报警
    if request.json.get('data') > sensor.max :
        alert = Alert()
        alert.warning_data_id = data.id
        alert.warning_data_max = sensor.max
        alert.warning_data_min = sensor.min
        alert.warning_reason = '数据超出上限值'
        db.session.add(alert)
        db.session.commit()
    elif request.json.get('data') < sensor.min:
        alert = Alert()
        alert.warning_data_id = data.id
        alert.warning_data_max = sensor.max
        alert.warning_data_min = sensor.min
        alert.warning_reason = '数据低于下限值'
        db.session.add(alert)
        db.session.commit()
    else:
        pass
    return jsonify({'status': 200})
#下载数据
@api.route('/device/<int:did>/sensor/<int:sid>/data')
@auth.login_required
def get_data(did, sid):
    device = g.current_user.devices.filter_by(id=did).first()
    if device is None :
        return jsonify({'status':404, 'info':'找不到你的设备'})

    sensor = device.sensors.filter_by(id=sid).first()
    if sensor is None :
        return jsonify({'status':404, 'info':'找不到你的传感器'})
    datas = sensor.datas.order_by(Data.set_time.desc()).all()
    if datas is None:
        return jsonify({'status': 404, 'info': '找不到你的数据'})
    dlist=[]
    for i in datas:
        dlist.append(i.to_json())
    return jsonify({'status':200, 'data':dlist})

#获设备的传感器
@api.route('/device/<int:did>/sensors')
@auth.login_required
def sensors(did):
    device = g.current_user.devices.filter_by(id=did).first()
    if device is None:
        return jsonify({'status': 404, 'info':'找不到你的设备'})
    sensors= device.sensors.all()
    if sensors is None:
        return jsonify({'status': 404, 'info': '找不到你的传感器'})
    slist=[]
    for s in sensors:
        slist.append(s.to_json())
    return jsonify({'status': 200, 'sensors': slist})


#分页下载数据
@api.route('/device/<int:did>/sensor/<int:sid>/datas')
@auth.login_required
def datas(did, sid):
    device = g.current_user.devices.filter_by(id=did).first()
    if device is None:
        return jsonify({'status':404, 'info': '找不到你的设备'})
    sensor = device.sensors.filter_by(id=sid).first()
    if sensor is None:
        return jsonify({'status':200, 'info': '找不到你的传感器'})
    query = sensor.datas
    page_index = request.args.get('page', default=1, type=int)
    paginate = query.order_by(Data.set_time.desc()).paginate(page_index, 10,
                                                             False)
    dlist=[]
    for data in paginate.items:
        dlist.append(data.to_json())

    return jsonify({'status': 200, 'datas': dlist})


