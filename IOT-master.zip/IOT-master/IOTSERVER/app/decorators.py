from flask import abort
from flask_login import current_user
from app.models import Permission
from functools import wraps

def permission_decordator(permissions):
    def decordator(fun):
        @wraps(fun)
        def dec_fun(*args, **kwargs):
            if not current_user.has_permissions(permissions):
                abort(403)
            return fun(*args, **kwargs)
        return dec_fun
    return decordator

    def decorator_admin(fun):
        return permission_decordator(0XFFFF)(fun)

