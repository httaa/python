from app import create_app
from app import db
from flask_script import Manager, Shell
from app.models import User
import pymysql
from flask_migrate import Migrate, MigrateCommand
from app.models import Device,Sensor
pymysql.install_as_MySQLdb()

app = create_app('test')

manager = Manager(app)

#创建一个数据库迁移对象（修改表）
migrate = Migrate(app, db)

#增加一条命令叫做db经常
manager.add_command('db', MigrateCommand)

#输入库迁移具体步骤
#1.创建数据库迁移需要的目录和脚本文件
# venv\Scripts\python.exe run.py db init
#2.统计数据模型和表之前的区别
# venv\Scripts\python.exe run.py db migrate -m 'add age in student'
#3.第二部统计到的区别更新到数据库（修改表）
# venv\Scripts\python.exe run.py db upgrade

def make_context() :
    return dict(db=db, User=User, Sensor=Sensor, Device=Device)

manager.add_command('shell', Shell(make_context=make_context))

from app.models import Role
@manager.command
def init():
    Role.create_roles()

from app.models import Permission
app.add_template_global(Permission,'Permission')


manager.run()






