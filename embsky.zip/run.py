from app import create_app
from app import db
import pymysql
from flask_script import Manager, Shell
from flask_migrate import Migrate, MigrateCommand
from app.models import User,Permission

pymysql.install_as_MySQLdb()

app = create_app('develop')

manager = Manager(app)
migrate = Migrate(app, db)
manager.add_command('db',MigrateCommand)
app.add_template_global(Permission, 'Permission')
def make_context() :
    return dict(db=db,User = User)

manager.add_command('shell', Shell(make_context=make_context))

from app.models import Role
@manager.command
def init():
    Role.create_roles()
from app.models import Permission
app.add_template_global(Permission,'Permission')

# def run():
    # from werkzeug.contrib.fixers import ProxyFix
    # app.wsgi_app = ProxyFix(app.wsgi_app)
    # app.run(host='0.0.0.0',port=1234,threaded = True)
# if __name__ =='main':
    # app.run(debug=True)
manager.run()
# app.run()