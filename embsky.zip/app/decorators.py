from functools import wraps
from flask import abort
from flask_login import current_user
from app.models import Permission

def decorator_permission(permissions):
    def permission_fun(fun):
        @wraps(fun)
        def p_fun():
            if current_user.has_permission(permissions):
                ret = fun()
                return ret
            abort(403)
        return p_fun
    return permission_fun

def decorator_admin(fun):
    return decorator_permission(0xff)(fun)