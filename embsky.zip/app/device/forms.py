from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField,FloatField
from wtforms.validators import DataRequired, Email, Length, Regexp, EqualTo
from wtforms import TextAreaField


class AddDeviceForm(FlaskForm):
    name = StringField(label='名字', validators=[DataRequired(), Length(1, 128)])
    desc = TextAreaField(label='描述',validators=[DataRequired(),Length(1,256)])
    addr = StringField(label='位置',validators=[DataRequired(),Length(1,128)])
    submit = SubmitField(label='确认编辑')


class EditDeviceForm(FlaskForm) :
    name = StringField(label='名字', validators=[DataRequired(), Length(1, 128)])
    desc = TextAreaField(label='描述', validators=[DataRequired(), Length(1, 256)])
    addr = StringField(label='位置', validators=[DataRequired(), Length(1, 128)])
    submit = SubmitField(label='确认编辑')


class AddSensorForm(FlaskForm):
    name = StringField(label='名字', validators=[DataRequired(), Length(1, 128)])
    desc = TextAreaField(label='描述',validators=[DataRequired(),Length(1,256)])
    unit = StringField(label='单位',validators=[DataRequired(),Length(1,128)])
    max = FloatField(label='最大值',validators=[DataRequired()])
    min = FloatField(label='最小值', validators=[DataRequired()])
    submit = SubmitField(label='确认编辑')


class EditSensorForm(FlaskForm) :
    name = StringField(label='名字', validators=[DataRequired(), Length(1, 128)])
    desc = TextAreaField(label='描述', validators=[DataRequired(), Length(1, 256)])
    unit = StringField(label='单位', validators=[DataRequired(), Length(1, 128)])
    submit = SubmitField(label='确认编辑')