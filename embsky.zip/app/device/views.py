from flask import render_template, redirect, request, abort, url_for
from . import device
from flask_login import login_required
from .forms import AddDeviceForm, EditDeviceForm, AddSensorForm, EditSensorForm
from app.models import Device, Sensor
from flask_login import current_user
from app import db


@device.route('/devices')
@login_required
def devices() :
    id = request.args.get('id')
    all = Device.query.filter_by(user_id=id)
    page = request.args.get('page', type=int, default=1)
    paginate = all.paginate(page=page, per_page=10, error_out=False)
    return render_template('device/devices.html',all=all, id=id, paginate=paginate)


@device.route('/add_device', methods=['GET', 'POST'])
@login_required
def add_device():
    form = AddDeviceForm()
    id = request.args.get('id')
    # did = request.args.get('did')
    if form.validate_on_submit():
        devices = Device()
        devices.name = form.name.data
        devices.addr = form.addr.data
        devices.desc = form.desc.data
        devices.user_id = id
        db.session.add(devices)
        db.session.commit()
        return redirect(url_for('device.devices', id=id))
    return render_template('device/add_devices.html', form=form)


@device.route('/desc')
@login_required
def desc():
    did = request.args.get('did')
    devices = Device.query.filter_by(id=did)
    sensors = Sensor.query.filter_by(device_id=did).all()
    return render_template('device/desc.html', devices=devices, sensors=sensors)


@device.route('/delete_device')
@login_required
def delete_device():
    did = request.args.get('did')
    devices = Device.query.filter_by(id=did).first()
    # if current_user.id == Device.user_id or current_user.is_admin():
    db.session.delete(devices)
    db.session.commit()
    return redirect(url_for('device.devices', id=current_user.id))


@device.route('/edit_device', methods=['GET', 'POST'])
def edit_device():
    did = request.args.get('did')
    form = EditDeviceForm()
    device = Device.query.filter_by(id=did).first()
    if form.validate_on_submit():
        device.name = form.name.data
        device.addr = form.addr.data
        device.desc = form.desc.data
        device.user_id = current_user.id
        db.session.add(device)
        db.session.commit()
        return redirect(url_for('device.devices', id=current_user.id))
    form.name.data = device.name
    form.desc.data = device.name
    form.addr.data = device.addr
    return render_template('device/edit_device.html', form=form)


@device.route('/add_sensor', methods=['GET', 'POST'])
def add_sensor():
    did = request.args.get('did')
    form = AddSensorForm()
    if form.validate_on_submit():
        sensor = Sensor()
        sensor.name = form.name.data
        sensor.desc = form.desc.data
        sensor.unit = form.unit.data
        sensor.max = form.max.data
        sensor.min = form.min.data
        sensor.device_id = did
        db.session.add(sensor)
        db.session.commit()
        return redirect(url_for('device.desc',did=did))
    return render_template('device/add_sensor.html', form=form)


@device.route('/delete_sensor')
@login_required
def delete_sensor():
    sid = request.args.get('sid')
    sensors = Sensor.query.filter_by(id=sid).first()
    did = sensors.device.id
    # print(did)
    # if current_user == Device.user_id or current_user.is_admin():
    db.session.delete(sensors)
    db.session.commit()
    return redirect(url_for('device.desc', did=did))


@device.route('/edit_sensor',methods=['GET', 'POST'])
@login_required
def edit_sensor():
    sid = request.args.get('sid')
    form = EditSensorForm()
    sensors = Sensor.query.filter_by(id=sid).first()
    did = sensors.device.id
    if form.validate_on_submit():
        sensors.name = form.name.data
        sensors.desc = form.desc.data
        sensors.unit = form.unit.data
        db.session.add(sensors)
        db.session.commit()
        return redirect(url_for('device.desc', did=did))
    form.name.data = sensors.name
    form.desc.data = sensors.desc
    form.unit.data = sensors.unit
    return render_template('device/edit_sensor.html', form=form)


from app.models import Data
@device.route('/data')
@login_required
def data():
    sid = request.args.get('sid')
    sensor = Sensor.query.filter_by(id=sid).first()
    # print(sensor.datas)
    # data = Data.query.all()
    page = request.args.get('page', type=int, default=1)
    paginate = sensor.datas.order_by(Data.timestamp.desc()).paginate(page=page, per_page=10, error_out=False)
    data_count = len(paginate.items) // 3
    data1 = paginate.items[: data_count]
    data2 = paginate.items[data_count:data_count*2]
    data3 = paginate.items[data_count*2:]
    items = paginate.items[::-1]
    xlist = []
    ylist = []
    for items in items:
        xlist.append(items.timestamp.strftime('%y-%m-%d %H:%M:%S'))
        ylist.append(items.data)
    # for d in data:
    #     pass
    # sensors = Sensor.query.filter_by(id=sid).first()
    # did = sensors.device.id
    return render_template('device/data.html', id=sid, data1=data1, data2=data2, data3=data3, paginate=paginate, items=items,
                           xlist=xlist, ylist=ylist, sensor=sensor)



