from app import db
from itsdangerous import TimedJSONWebSignatureSerializer as Serialize
from flask import current_app
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from datetime import datetime
'''
add at 19/5/8
增加反向关系在data中，增加了news    
'''


class User(db.Model, UserMixin) :
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64))
    password_hash = db.Column(db.String(128))
    email = db.Column(db.String(64))
    confirmed = db.Column(db.Boolean, default=False)
    about_me = db.Column(db.Text())
    location = db.Column(db.String(128))
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id', ondelete='CASCADE'))
    register_time = db.Column(db.DateTime, default=datetime.now)
    access_time = db.Column(db.DateTime, default=datetime.now)
    api_key = db.Column(db.String(128))
    devices = db.relationship('Device', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    '''edit at 19/5/8 add new'''
    news = db.relationship('News', backref='user', lazy='dynamic', cascade='all, delete-orphan')

    def __str__(self):
        return '[' + self.name + ':' + str(self.id) + ']'

    def flush_access_time(self):
        self.access_time = datetime.now()
        db.session.add(self)
        db.session.commit()

    @property
    def password(self):
        raise AttributeError('密码不允许读取')

    @password.setter
    def password(self, pd):
        self.password_hash = generate_password_hash(pd)

    def check_password(self, pd):
        return check_password_hash(self.password_hash, pd)

    def generate_confirmed_token(self):
        s = Serialize(secret_key=current_app.config['SECRET_KEY'],expires_in=120)
        token = s.dumps({'id': self.id})
        return token

    def confirm(self, token) :
        s = Serialize(secret_key=current_app.config['SECRET_KEY'])
        try:
            d = s.loads(token)
        except:
            return False
        if d.get('id') == self.id:
            self.confirmed = True
            db.session.add(self)
            db.session.commit()
            return True
        return False

    # 为了支持智能硬件用户验证，添加API_KEY的支持
    # 1.生成API—KEY
    def generate_api_token(self):
        s = Serialize(secret_key=current_app.config['SECRET_KEY'], expires_in=60*60*24*365*100)
        self.api_key = s.dumps({'id':self.id})
        db.session.add(self)
        db.session.commit()

    # 2.获取API—KEY
    def get_api_token(self):
        return self.api_key

    # 3.验证API_KEY 如果验证成功返回用户对象，否则返回None
    @staticmethod
    def check_api_token(token):
        s = Serialize(secret_key=current_app.config['SECRET_KEY'])
        try:
            data = s.loads(token)
        except:
            return None
        if 'id' not in data.keys():
            return None
        return User.query.filter_by(id=int(data['id'])).first()

    def has_permission(self, permission):
        return self.role.permissions & permission == permission

    def is_admin(self):
        return self.has_permission(0xff)

    def is_users(self):
        return self.has_permission(Permission.ADD_DEVICE | Permission.ADD_SENSOR | Permission.DELETE_DEVICE
                                   | Permission.DELETE_SENSOR | Permission.EDIT_DEVICE | Permission.EDIT_SENSOR
                                   | Permission.EDIT_USER)

from flask_login import AnonymousUserMixin


class AnonymousUser(AnonymousUserMixin):
    name = '游客'

    def has_permission(self, permisssions):
        return False

    def flush_access_time(self):
        pass

    def is_admin(self):
        return False

from app import login_manager
@login_manager.user_loader
def user_load(id):
    return User.query.get(int(id))


class Permission():
    # 设备
    ADD_DEVICE = 0X0001
    DELETE_DEVICE = 0X0002
    EDIT_DEVICE = 0X0004
    # 传感器
    ADD_SENSOR = 0X0008
    DELETE_SENSOR = 0X0010
    EDIT_SENSOR = 0X0020
    # 用户
    ADD_USER = 0X0040
    DELETE_USER = 0X0080
    EDIT_USER = 0X0100


class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
    default = db.Column(db.Boolean, default=False)
    permissions = db.Column(db.Integer)
    users = db.relationship('User', backref='role')

    @staticmethod
    def create_roles():
        roles = {
            'user': [Permission.ADD_DEVICE | Permission.ADD_SENSOR | Permission.DELETE_DEVICE | Permission.DELETE_SENSOR | Permission.EDIT_DEVICE | Permission.EDIT_SENSOR | Permission.EDIT_USER, True],
            'Enterprise_users': [Permission.EDIT_SENSOR | Permission.EDIT_DEVICE | Permission.EDIT_USER, False],
            'admin': [0XFFFF, False],
        }
        for name in roles:
            role = Role.query.filter_by(name=name).first()
            if role is None:
                role = Role()
                role.name = name
            role.permissions = roles[name][0]
            role.default = roles[name][1]
            db.session.add(role)
        db.session.commit()


class Device(db.Model):
    __tablename__ = 'devices'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    desc = db.Column(db.Text)
    addr = db.Column(db.String(128))
    timestamp = db.Column(db.DateTime, default=datetime.now)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'))
    sensors = db.relationship('Sensor', backref='device', lazy='dynamic', cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='device', lazy='dynamic', cascade='all, delete-orphan')

    def to_json(self):
        json_data = {
            'id': self.id,
            'name': self.name,
            'user': self.user.name,
            'timestamp': self.timestamp,
        }
        return json_data


class Sensor(db.Model) :
    __tablename__ = 'sensors'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128))
    desc = db.Column(db.Text)
    data = db.Column(db.Float, default=0)
    unit = db.Column(db.String(32),default='data')
    timestamp = db.Column(db.DateTime, default=datetime.now)
    device_id = db.Column(db.Integer, db.ForeignKey('devices.id', ondelete='CASCADE'))
    datas = db.relationship('Data', backref='sensor', lazy='dynamic', cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='sensor', lazy='dynamic', cascade='all, delete-orphan')

    max = db.Column(db.Float, default=1.0)
    min = db.Column(db.Float, default=1.0)

    def to_json(self):
        json_data = {
            'id':self.id,
            'name':self.name,
            'desc':self.desc,
            'device':self.device.name,
            'max':self.max,
            'min':self.min,
            'data':self.data,
            'unit':self.unit,
            'timestamp':self.timestamp
        }
        return json_data


class Data(db.Model) :
    __tablename__ = 'datas'
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.Float)
    timestamp = db.Column(db.DateTime,default=datetime.now)
    sensor_id = db.Column(db.Integer, db.ForeignKey('sensors.id',ondelete='CASCADE'))
    alters = db.relationship('Alert', backref='data',lazy='dynamic',cascade='all, delete-orphan')

    def to_json(self):
        json_data = {
            'id':self.id,
            'data':self.data,
            'timestamp':self.timestamp,
            'sensor':self.sensor.name,
        }
        return json_data


class Alert(db.Model):
    __tablename__ = 'alerts'
    id = db.Column(db.Integer, primary_key=True)
    max = db.Column(db.Float)
    min = db.Column(db.Float)
    desc = db.Column(db.String(128))
    # data = db.Column(db.Float)

    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'))
    device_id = db.Column(db.Integer, db.ForeignKey('devices.id', ondelete='CASCADE'))
    sensor_id = db.Column(db.Integer, db.ForeignKey('sensors.id', ondelete='CASCADE'))
    data_id = db.Column(db.Integer, db.ForeignKey('datas.id', ondelete='CASCADE'))


class News(db.Model):
    __tablename__ = 'news'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128))
    body = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.now)
    private = db.Column(db.Boolean, default=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'))
