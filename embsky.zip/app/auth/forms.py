from flask_wtf import FlaskForm
from wtforms import StringField,TextAreaField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Regexp, EqualTo
from ..models import User
from wtforms import ValidationError


class LoginForm(FlaskForm) :
    email = StringField(label='邮箱', validators=[DataRequired(), Email('邮箱或密码不对'), Length(6,128)])
    password = PasswordField(label='密码', validators=[DataRequired(), Length(1, 128)])
    remember_me = BooleanField(label='记住我')
    submit = SubmitField(label='登陆')


class RegisterForm(FlaskForm):
    email = StringField(label='邮箱',validators=[DataRequired(),Length(6,128),Email()])
    name = StringField(label='昵称',validators=[DataRequired(),Length(6,64)])
    location = StringField(label='位置', validators=[DataRequired(), Length(1, 64)])
    about_me = TextAreaField(label='签名', validators=[DataRequired(), Length(1, 256)])
    password = PasswordField(label='密码',validators=[DataRequired()])
    password_again = PasswordField(label='确认密码',validators=[DataRequired(),EqualTo('password',message='两次密码不一致')])
    submit = SubmitField(label='注册')