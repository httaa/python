from flask_mail import Mail
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import config
from flask_login import LoginManager
from flask_bootstrap import Bootstrap

mail = Mail()
db = SQLAlchemy()
bootstrap = Bootstrap()
login_manager = LoginManager()
login_manager.session_protection = 'strong'
login_manager.login_view = 'auth.login'
from app.models import AnonymousUser
login_manager.anonymous_user = AnonymousUser


def create_app(config_name) :
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    mail.init_app(app)
    bootstrap.init_app(app)
    db.init_app(app)
    login_manager.init_app(app)

    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)

    from .auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint, url_prefix='/auth')

    from .manager import manager as manager_blueprint
    app.register_blueprint(manager_blueprint, url_prefix='/manager')

    from .device import device as device_blueprint
    app.register_blueprint(device_blueprint,url_prefix='/device')

    from .api1_0 import api as api_blueprint
    app.register_blueprint(api_blueprint,url_prefix='/api/1_0')
    return app