from flask import render_template,url_for,redirect,request
from flask import abort, flash
from flask_login import login_required
from . import main
from app.models import User, Alert,Data, News
from app.auth.forms import LoginForm
from .forms import EditUserForm, SearchForm, PostNewsForm
from flask_login import current_user
from app import db
from flask_login import login_required, login_user, logout_user


@main.route('/', methods=['GET', 'POST'])
def index() :
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user is not None and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect(url_for('main.user_info', id = user.id))
        else:
            flash('邮箱或者密码错误，请重新登录!')
    return render_template('main/index.html', form=form)


@main.route('/user_info')
@login_required
def user_info() :
    id = request.args.get('id')
    if id is None:
        abort(404)
    user = User.query.filter_by(id = id).first()
    news = News.query.filter_by(user_id=id).all()
    if user is None:
        abort(404)
    return render_template('main/user_info.html', user=user, news=news)


@main.route('/edit_user',methods=['GET','POST'])
@login_required
def edit_user():
    form = EditUserForm()
    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.about_me = form.about_me.data
        current_user.location = form.location.data
        if len(form.password.data) != 0:
            current_user.password = form.password.data
        db.session.add(current_user)
        db.session.commit()
        return redirect(url_for('.user_info', id=current_user.id))
    form.email.data = current_user.email
    form.name.data = current_user.name
    form.location.data = current_user.location
    form.about_me.data = current_user.about_me
    return render_template('main/edit_user.html', form=form)


@main.route('/alert,', methods=['GET', 'POST'])
@login_required
def alert():
    id = request.args.get('id')
    print(id)
    page = request.args.get('pag', type=int, default=1)
    alerts = Alert.query.order_by(Alert.desc!=None).paginate(page=page, per_page=10, error_out=False)
    form = SearchForm()
    if form.validate_on_submit():
        page = request.args.get('page', type=int, default=1)
        sensor_id = form.data.data
        return redirect(url_for('main.alerts', sensor_id=sensor_id))
    return render_template('main/alert.html', alerts=alerts, form=form, id=id)


@main.route('/post_news', methods=['GET', 'POST'])
@login_required
def post_news():
    form = PostNewsForm()
    if form.validate_on_submit():
        new = News()
        new.body = form.body.data
        new.private = form.private.data
        new.title = form.title.data
        new.user_id = current_user.id
        db.session.add(new)
        db.session.commit()
        return redirect(url_for('main.user_info', id=current_user.id))
    return render_template('main/post_news.html', form=form)


@main.route('/news')
@login_required
def news():
    nid = request.args.get('nid')
    if nid is None:
        abort(404)
    news = News.query.filter_by(id=nid).first()
    if news is None:
        abort(404)
    return render_template('main/news.html', news=news)


@main.route('/delete_news')
@login_required
def delete_news():
    nid = request.args.get('nid')
    if nid is None:
        abort(404)
    news = News.query.filter_by(id=nid).first()
    if news is None:
        abort(404)
    if current_user == news.user or current_user.is_admin():
        db.session.delete(news)
        db.session.commit()
    return redirect(url_for('main.user_info', id=current_user.id))


@main.route('/edit_news', methods=['GET', 'POST'])
@login_required
def edit_news():
    nid = request.args.get('nid')
    if nid is None:
        abort(404)
    news = News.query.filter_by(id=nid).first()
    if news is None:
        abort(404)
    form = PostNewsForm()
    if form.validate_on_submit():
        news.title = form.title.data
        news.body = form.body.data
        news.private = form.private.data
        db.session.add(news)
        db.session.commit()
        return redirect(url_for('main.news', nid=nid))
    form.title.data = news.title
    form.body.data = news.body
    return render_template('main/post_news.html', form=form)

